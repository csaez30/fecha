/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practico.pkg6.clases;

/**
 *
 * @author luciano.echevarne
 */
public class main {
    public static void main(String[] args) {
    
//        Cliente c1=new Cliente("Luciano","Echevarne","Pergamino","33097243","B cerro");
//        Cliente c2=new Cliente("Pedro","Gonzalez","Pergamino","3443322","porhai");
//        Cliente c3=new Cliente("Jorge","Echevarne","Pergamino","33097243","B cerro");
//        
//        Listas l1=new Listas();
//        l1.agregarCliente(445538L, c1);  
//        l1.agregarCliente(446638L, c2);
//        l1.agregarCliente(447738L, c3);
//        System.out.println(l1.agregarCliente(445537L, c1));
//        System.out.println(l1.buscarCliente(445537L));
//        System.out.println(l1.buscarTelefono("Echevarne"));
//        System.out.println(l1.buscarClientes("Pergamino"));
//        System.out.println(l1.borrarCliente("33097243"));
//        System.out.println(l1.buscarClientes("Pergamino"));
//        System.out.println(l1.buscarTelefono("Gonzalez"));
    }
}